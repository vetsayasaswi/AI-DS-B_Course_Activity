# College Management - Room Service (Spring Boot)

This project implements a Rooms microservice for a College Management System using Spring Boot, JPA (Hibernate), and MySQL.

## Features
- CRUD REST APIs for Room entity
- Validation using Jakarta Bean Validation (`@NotBlank`, `@NotNull`, `@Min`)
- Global exception handling
- Persists to MySQL

## Project Structure
- `com.example.rooms.entity.RoomEntity` - JPA entity
- `com.example.rooms.repository.RoomRepository` - JPA repository
- `com.example.rooms.service` - service interface and implementation
- `com.example.rooms.controller.RoomController` - REST controller
- `com.example.rooms.exception` - custom exception + global handler

## Requirements
- Java 17+
- Maven
- MySQL running locally (or change `application.properties` accordingly)

## Setup
1. Update `src/main/resources/application.properties` with your DB credentials and database name.
2. Create the database manually if it doesn't exist:
   ```sql
   CREATE DATABASE college_db;
   ```
3. Build and run:
   ```bash
   mvn clean package
   mvn spring-boot:run
   ```

## API Endpoints
- `POST /api/rooms` - Create room
- `GET /api/rooms` - Get all rooms
- `GET /api/rooms/{id}` - Get room by id
- `PUT /api/rooms/{id}` - Update room
- `DELETE /api/rooms/{id}` - Delete room

