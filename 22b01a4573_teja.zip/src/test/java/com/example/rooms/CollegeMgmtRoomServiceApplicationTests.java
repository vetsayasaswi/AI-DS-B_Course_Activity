package com.example.rooms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeMgmtRoomServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}
