package com.example.rooms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeMgmtRoomServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollegeMgmtRoomServiceApplication.class, args);
    }
}
