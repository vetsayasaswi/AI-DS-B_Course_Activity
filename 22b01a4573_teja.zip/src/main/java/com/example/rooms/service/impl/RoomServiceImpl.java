package com.example.rooms.service.impl;

import com.example.rooms.entity.RoomEntity;
import com.example.rooms.exception.ResourceNotFoundException;
import com.example.rooms.repository.RoomRepository;
import com.example.rooms.service.RoomService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public RoomEntity createRoom(RoomEntity room) {
        room.setRoomId(null); // ensure new
        return roomRepository.save(room);
    }

    @Override
    public List<RoomEntity> getAllRooms() {
        return roomRepository.findAll();
    }

    @Override
    public RoomEntity getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    @Override
    public RoomEntity updateRoom(Long id, RoomEntity room) {
        RoomEntity existing = roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
        existing.setDept(room.getDept());
        existing.setCapacity(room.getCapacity());
        existing.setBuildingName(room.getBuildingName());
        existing.setBlock(room.getBlock());
        return roomRepository.save(existing);
    }

    @Override
    public void deleteRoom(Long id) {
        RoomEntity existing = roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
        roomRepository.delete(existing);
    }
}
