package com.example.room_service.service;

import com.example.room_service.entity.RoomEntity;
import java.util.List;

public interface RoomService {
    RoomEntity createRoom(RoomEntity room);
    List<RoomEntity> getAllRooms();
    RoomEntity getRoomById(Long id);
    RoomEntity updateRoom(Long id, RoomEntity room);
    void deleteRoom(Long id);
}
