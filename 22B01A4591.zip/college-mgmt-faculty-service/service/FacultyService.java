package com.college.faculty.service;

import com.college.faculty.entity.FacultyEntity;
import com.college.faculty.repository.FacultyRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacultyService {

    private final FacultyRepository repository;

    public FacultyService(FacultyRepository repository) {
        this.repository = repository;
    }

    public FacultyEntity createFaculty(FacultyEntity faculty) {
        return repository.save(faculty);
    }

    public List<FacultyEntity> getAllFaculties() {
        return repository.findAll();
    }

    public Optional<FacultyEntity> getFacultyById(Long id) {
        return repository.findById(id);
    }

    public FacultyEntity updateFaculty(Long id, FacultyEntity faculty) {
        return repository.findById(id).map(existing -> {
            existing.setName(faculty.getName());
            existing.setDept(faculty.getDept());
            existing.setDesignation(faculty.getDesignation());
            existing.setEmail(faculty.getEmail());
            existing.setPhoneNo(faculty.getPhoneNo());
            return repository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Faculty not found"));
    }

    public void deleteFaculty(Long id) {
        repository.deleteById(id);
    }
}
