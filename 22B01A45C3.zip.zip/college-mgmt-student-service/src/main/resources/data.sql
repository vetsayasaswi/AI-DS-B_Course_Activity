INSERT INTO students (roll_no, name, dept, section, aadhar_id, skills, cgpa)
VALUES ('CS2025-001', 'Alice Kumar', 'CSE', 'A', '123456789012', 'Java,SQL', 8.6);
