package com.collegemgmt.studentservice.controller;

import com.collegemgmt.studentservice.entity.StudentEntity;
import com.collegemgmt.studentservice.service.StudentService;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@Validated
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<StudentEntity> createStudent(@Valid @RequestBody StudentEntity student) {
        StudentEntity created = service.createStudent(student);
        return ResponseEntity.created(URI.create("/api/students/" + created.getRegId()))
                             .body(created);
    }

    @GetMapping
    public ResponseEntity<List<StudentEntity>> getAllStudents() {
        return ResponseEntity.ok(service.getAllStudents());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StudentEntity> getStudentById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(service.getStudentById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<StudentEntity> updateStudent(@PathVariable("id") Long id,
                                                       @Valid @RequestBody StudentEntity student) {
        StudentEntity updated = service.updateStudent(id, student);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable("id") Long id) {
        service.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }
}
