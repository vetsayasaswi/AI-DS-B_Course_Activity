package com.collegemgmt.studentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeMgmtStudentServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CollegeMgmtStudentServiceApplication.class, args);
    }
}
