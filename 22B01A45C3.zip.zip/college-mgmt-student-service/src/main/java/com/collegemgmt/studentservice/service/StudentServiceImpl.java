package com.collegemgmt.studentservice.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.collegemgmt.studentservice.entity.StudentEntity;
import com.collegemgmt.studentservice.repository.StudentRepository;
import com.collegemgmt.studentservice.exception.ResourceNotFoundException;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentRepository repository;

    public StudentServiceImpl(StudentRepository repository) {
        this.repository = repository;
    }

    @Override
    public StudentEntity createStudent(StudentEntity student) {
        if (student.getRollNo() != null && repository.existsByRollNo(student.getRollNo())) {
            throw new DataIntegrityViolationException("Roll number already exists");
        }
        return repository.save(student);
    }

    @Override
    public List<StudentEntity> getAllStudents() {
        return repository.findAll();
    }

    @Override
    public StudentEntity getStudentById(Long regId) {
        return repository.findById(regId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with regId: " + regId));
    }

    @Override
    public StudentEntity updateStudent(Long regId, StudentEntity updated) {
        StudentEntity existing = getStudentById(regId);
        // check uniqueness before changing rollNo
        if (updated.getRollNo() != null && !updated.getRollNo().equals(existing.getRollNo())
                && repository.existsByRollNo(updated.getRollNo())) {
            throw new DataIntegrityViolationException("Roll number already exists");
        }
        existing.setRollNo(updated.getRollNo());
        existing.setName(updated.getName());
        existing.setDept(updated.getDept());
        existing.setSection(updated.getSection());
        existing.setAadharId(updated.getAadharId());
        existing.setSkills(updated.getSkills());
        existing.setCgpa(updated.getCgpa());
        return repository.save(existing);
    }

    @Override
    public void deleteStudent(Long regId) {
        StudentEntity existing = getStudentById(regId);
        repository.delete(existing);
    }
}
