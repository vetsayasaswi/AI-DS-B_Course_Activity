package com.collegemgmt.studentservice.service;

import com.collegemgmt.studentservice.entity.StudentEntity;
import java.util.List;

public interface StudentService {
    StudentEntity createStudent(StudentEntity student);
    List<StudentEntity> getAllStudents();
    StudentEntity getStudentById(Long regId);
    StudentEntity updateStudent(Long regId, StudentEntity updated);
    void deleteStudent(Long regId);
}
