package com.collegemgmt.studentservice.entity;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name = "students", indexes = {
    @Index(columnList = "roll_no", name = "idx_rollno")
})
public class StudentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long regId;

    @Column(name = "roll_no", nullable = false, unique = true, length = 50)
    @NotBlank(message = "Roll number is required")
    @Size(max = 50)
    private String rollNo;

    @Column(nullable = false)
    @NotBlank(message = "Name is required")
    @Size(max = 100)
    private String name;

    @Column(nullable = false)
    @NotBlank(message = "Department is required")
    @Size(max = 100)
    private String dept;

    @Column(nullable = false)
    @NotBlank(message = "Section is required")
    @Size(max = 10)
    private String section;

    @Column(name = "aadhar_id", length = 12)
    @Pattern(regexp = "^[0-9]{12}$", message = "Aadhar must be 12 digits")
    private String aadharId;

    @Column(length = 500)
    private String skills;

    @Column
    @DecimalMin(value = "0.0", inclusive = true, message = "CGPA must be >= 0.0")
    @DecimalMax(value = "10.0", inclusive = true, message = "CGPA must be <= 10.0")
    private Double cgpa;

    public StudentEntity() {}

    public Long getRegId() { return regId; }
    public void setRegId(Long regId) { this.regId = regId; }

    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDept() { return dept; }
    public void setDept(String dept) { this.dept = dept; }

    public String getSection() { return section; }
    public void setSection(String section) { this.section = section; }

    public String getAadharId() { return aadharId; }
    public void setAadharId(String aadharId) { this.aadharId = aadharId; }

    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }

    public Double getCgpa() { return cgpa; }
    public void setCgpa(Double cgpa) { this.cgpa = cgpa; }
}
