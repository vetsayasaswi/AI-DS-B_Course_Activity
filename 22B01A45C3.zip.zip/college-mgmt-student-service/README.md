# college-mgmt-student-service

Spring Boot microservice to manage student records, backed by MySQL.

## Run
1. Create MySQL db: `CREATE DATABASE college_mgmt;`
2. Update `src/main/resources/application.properties` with DB credentials.
3. Build: `mvn clean package`
4. Run: `java -jar target/college-mgmt-student-service-1.0.0.jar`
OR: `mvn spring-boot:run`

## Endpoints
- POST /api/students
- GET /api/students
- GET /api/students/{id}
- PUT /api/students/{id}
- DELETE /api/students/{id}
