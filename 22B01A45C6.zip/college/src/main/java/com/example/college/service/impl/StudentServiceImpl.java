package com.example.college.service.impl;

import com.example.college.entity.StudentEntity;
import com.example.college.repository.StudentRepository;
import com.example.college.service.StudentService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService{
	
	private final StudentRepository studentRepository;
	
	public StudentServiceImpl(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}
	
	@Override
	public StudentEntity createStudent(StudentEntity student) {
		return studentRepository.save(student);
	}
	
	@Override
	public List<StudentEntity> getAllStudents() {
		return studentRepository.findAll();
	}
	
	@Override
	public StudentEntity getStudentById(Long id) {
		return studentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Student not found with id : " + id));
	}
	
	@Override
	public StudentEntity updateStudent(Long id, StudentEntity studentDetails) {
		StudentEntity student = getStudentById(id);
		
		student.setRollno(studentDetails.getRollno());
		student.setName(studentDetails.getName());
        student.setDept(studentDetails.getDept());
        student.setSection(studentDetails.getSection());
        student.setAadharId(studentDetails.getAadharId());
        student.setSkills(studentDetails.getSkills());
        student.setCgpa(studentDetails.getCgpa());

        return studentRepository.save(student);
	}
	
	@Override
	public void deleteStudent(Long id) {
		studentRepository.deleteById(id);
	}
	
	
}
