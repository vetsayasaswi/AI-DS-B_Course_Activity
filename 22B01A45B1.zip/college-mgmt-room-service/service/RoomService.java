package com.college.room.service;

import com.college.room.entity.RoomEntity;
import com.college.room.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    private final RoomRepository repository;

    public RoomService(RoomRepository repository) {
        this.repository = repository;
    }

    public RoomEntity createRoom(RoomEntity room) {
        return repository.save(room);
    }

    public List<RoomEntity> getAllRooms() {
        return repository.findAll();
    }

    public Optional<RoomEntity> getRoomById(Long id) {
        return repository.findById(id);
    }

    public RoomEntity updateRoom(Long id, RoomEntity room) {
        return repository.findById(id).map(existing -> {
            existing.setDept(room.getDept());
            existing.setCapacity(room.getCapacity());
            existing.setBuildingName(room.getBuildingName());
            existing.setBlock(room.getBlock());
            return repository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Room not found"));
    }

    public void deleteRoom(Long id) {
        repository.deleteById(id);
    }
}
