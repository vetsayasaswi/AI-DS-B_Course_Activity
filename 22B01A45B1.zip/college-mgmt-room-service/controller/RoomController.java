package com.college.room.controller;

import com.college.room.entity.RoomEntity;
import com.college.room.service.RoomService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService service;

    public RoomController(RoomService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RoomEntity> create(@Valid @RequestBody RoomEntity room) {
        RoomEntity created = service.createRoom(room);
        return ResponseEntity.created(URI.create("/api/rooms/" + created.getRoomId())).body(created);
    }

    @GetMapping
    public List<RoomEntity> getAll() {
        return service.getAllRooms();
    }

    @GetMapping("/<built-in function id>")
    public ResponseEntity<RoomEntity> getById(@PathVariable Long id) {
        return service.getRoomById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/<built-in function id>")
    public ResponseEntity<RoomEntity> update(@PathVariable Long id, @Valid @RequestBody RoomEntity room) {
        try {
            RoomEntity updated = service.updateRoom(id, room);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/<built-in function id>")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteRoom(id);
        return ResponseEntity.noContent().build();
    }
}
