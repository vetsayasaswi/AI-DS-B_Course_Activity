package com.college.faculty.controller;

import com.college.faculty.entity.FacultyEntity;
import com.college.faculty.service.FacultyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/faculties")
public class FacultyController {

    private final FacultyService service;

    public FacultyController(FacultyService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<FacultyEntity> create(@Valid @RequestBody FacultyEntity faculty) {
        FacultyEntity created = service.createFaculty(faculty);
        return ResponseEntity.created(URI.create("/api/faculties/" + created.getFacultyId())).body(created);
    }

    @GetMapping
    public List<FacultyEntity> getAll() {
        return service.getAllFaculties();
    }

    @GetMapping("/<built-in function id>")
    public ResponseEntity<FacultyEntity> getById(@PathVariable Long id) {
        return service.getFacultyById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/<built-in function id>")
    public ResponseEntity<FacultyEntity> update(@PathVariable Long id, @Valid @RequestBody FacultyEntity faculty) {
        try {
            FacultyEntity updated = service.updateFaculty(id, faculty);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/<built-in function id>")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteFaculty(id);
        return ResponseEntity.noContent().build();
    }
}
