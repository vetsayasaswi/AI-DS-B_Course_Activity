package com.college.student.service;

import com.college.student.entity.StudentEntity;
import com.college.student.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public StudentEntity createStudent(StudentEntity student) {
        return repository.save(student);
    }

    public List<StudentEntity> getAllStudents() {
        return repository.findAll();
    }

    public Optional<StudentEntity> getStudentById(Long id) {
        return repository.findById(id);
    }

    public StudentEntity updateStudent(Long id, StudentEntity student) {
        return repository.findById(id).map(existing -> {
            existing.setRollNo(student.getRollNo());
            existing.setName(student.getName());
            existing.setDept(student.getDept());
            existing.setSection(student.getSection());
            existing.setAadharId(student.getAadharId());
            existing.setSkills(student.getSkills());
            existing.setCgpa(student.getCgpa());
            return repository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public void deleteStudent(Long id) {
        repository.deleteById(id);
    }
}
