package com.college.student.controller;

import com.college.student.entity.StudentEntity;
import com.college.student.service.StudentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<StudentEntity> create(@Valid @RequestBody StudentEntity student) {
        StudentEntity created = service.createStudent(student);
        return ResponseEntity.created(URI.create("/api/students/" + created.getRegId())).body(created);
    }

    @GetMapping
    public List<StudentEntity> getAll() {
        return service.getAllStudents();
    }

    @GetMapping("/<built-in function id>")
    public ResponseEntity<StudentEntity> getById(@PathVariable Long id) {
        return service.getStudentById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/<built-in function id>")
    public ResponseEntity<StudentEntity> update(@PathVariable Long id, @Valid @RequestBody StudentEntity student) {
        try {
            StudentEntity updated = service.updateStudent(id, student);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/<built-in function id>")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }
}
